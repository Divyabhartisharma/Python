#Create a class of chess figure now inlcudes
## 1. color
## 2. title of game 
## 4. Here i have taken one element of chessboard is Queen


class Chessfigure:
#initiate function for all the attributes 
    def __init__(self,title,color,position):
        #self.Chessboard=Chessboard
        self.title = title
        self.color=color
        self.position=position
        #self.title=Title
        
#define a function for title
    def get_Title(self):
        #return self.title
        
        print("The title of game is:",self.title)

#Color position in chess
        
    def get_color(self,color):
        self.color="white"
##    def chess_position(self)

#now start the move for one element "Queen"
    #and particular postion of element is already mentioned in the class position in previous file 
    def chess_position(self):
         self.position=[
            ['WR','WK','WB','WQ','WK','WB','WK','WR'],
            ['Wp','Wp','Wp','Wp','Wp','Wp','Wp','Wp'],
            ['. ','. ','. ','. ','. ','. ','. ',' .'],
            ['. ','. ','. ','. ','. ','. ','. ','. '],
            ['. ','. ','. ','. ','. ','. ','. ','. '],
            ['. ','. ','. ',' .',' .',' .',' .',' .'],
            ['Bp','Bp','Bp','Bp','Bp','Bp','Bp','Bp'],
            ['BR','BK','BB','BQ','BK','BB','BK','BR'],
            ]
##    def Chess_show(self,x,y):
##         a="Queen"
##         print("position of:",a ,"\n" ,"for white :" ,self.position[x][y] ,"\n" ,"for black:" ,self.position[x][y])
    def chess_moves(self,row,column, moves):
        self.row=row
        self.column=column
        self.moves=moves
        
        #Here row ,coloumn is the output of board for me it is 2d list output so
        #moving this as 
        p=0;q=0;r= 0;
        s= 0;total = 0
 
    # Calculate initial and final of element 
    # coordinates are 
        p = row - moves
        q = row + moves
        r = column - moves
        s = column + moves
 
    # Since chessboard is of size 8X8 total of 64 which i have created in Chessboard.py by 2d list
    
    # so if any of coordinates will start from 1 to 8 in row and column
    #if a coordinate is less than  1 or greater than 8 make it 1 or 8.
        if (p < 1) :
            p = 1
        if (q < 1) :
            q = 1
        if (r > 8) :
            r = 8
        if (s > 8) :
            s = 8
 
    # Calculate total positions of queen 
        total_move= ((q - p + 1) * (s - r + 1) - 1)
        a="QUEEN"
        print("the element is:",a)
        print("total moves can be happen at that position is:\n",total_move)
        
    
        
        

F=Chessfigure("CHESSGAME","white",'Q')
F.get_Title()
F.get_color("white")
##F.Chess_show(1,2)
F.chess_position()

#If a Queen is on the position of row =2 column is also 2 the total moves of "QUEEN" possible as :
F.chess_moves(2,2,2)

#if a queen is on the position of row =5 column =4 the moves of queen can be possible as 3(diagonal ,staright column ,straight row) on that area total can moves by "QUEEN"
F.chess_moves(5,4,3)
##F.get_color()



 



