##Name:Divya Bharti Sharma

##Matriculation:7216426

##Python:Object oriented concepts


# CREATED A CLASS FOR CREATING CHESS BOARD AND THE CLASS FOR POSITION

# create a chessgame class and initialise the function and pass self in it to call the initialise state in other function in same class

class ChessGame:
    def __init__(self):
        #self.board=board
        
         # HERE MY BOARD IS (8X8)represent in 2d list
##        and with it i have all the 8 elements of chess which is rook,knight,bishop,queen,
##        king and same from right to left side
            #ROOK=R
            #KNIGHT=K
            #BISHOP=B
            #QUEEN=Q

            #KING=K
            #PAWN=P
         #In chess board i all play with my rows and columns so that i can check the elements and how it is available
##        
        self.board=[
            ['WR','WK','WB','WQ','WK','WB','WK','WR'],
            ['Wp','Wp','Wp','Wp','Wp','Wp','Wp','Wp'],
            ['. ','. ','. ','. ','. ','. ','. ',' .'],
            ['. ','. ','. ','. ','. ','. ','. ','. '],
            ['. ','. ','. ','. ','. ','. ','. ','. '],
            ['. ','. ','. ',' .',' .',' .',' .',' .'],
            ['Bp','Bp','Bp','Bp','Bp','Bp','Bp','Bp'],
            ['BR','BK','BB','BQ','BK','BB','BK','BR'],
            ]
        for elements in range(0,8):
            print(self.board[elements])
        #self.board = [list('P Q R S T U V W') for i in range(8)]

        #Now define a function to show how many elements are present in chess board
    def Chess_elements(self,total):
        self.total=total
        total =32
        p=16
        W=16
        B=16 
        print("Total elements of chess are:",total)
        print("total pawn are :",p)
        print("white elements are- including pawn:",W)
        print("black elements are (including pawn:",B)
        
    def take_elements(self):
        print("enter the white elements of chess board:\n",self.board[0],"\n",self.board[1])
        print ("enter the Black elements of chess board:\n",self.board[7],"\n",self.board[6])
        
    def get_position(self):
        print("sort form of white king from chess board:" ,self.board[0][4])
        print("sort form of black king from chess board:" ,self.board[7][4])
        

                     
c=ChessGame()
##c.display_board()
c.Chess_elements(32)
c.take_elements()
c.get_position()



#now here is the position of elements such as ifi provide 2,4 (rows,column) it will print the position of the element
#Created a class position

class position:
    #pass the self in initialise function 
    def __init__(self):
        #when i provide rows and column value it will provide particular element on that position 
        self.x=int(input("enter row value:"))
        self.y=int(input("Enter column value:"))
        self.list=[['WR','WK','WB','WQ','WK','WB','WK','WR'],
                   ['Wp','Wp','Wp','Wp','Wp','Wp','Wp','Wp'],
                   ['.','.','.','.','.','.','.','.'],
                   ['.','.','.','.','.','.','.','.'],
                   ['.','.','.','.','.','.','.','.'],
                   ['.','.','.','.','.','.','.','.'],
                   ['Bp','Bp','Bp','Bp','Bp','Bp','Bp','Bp'],
                   ['BR','BK','BB','BQ','BK','BB','BK','BR'],
                   ]   
      
    def get_position(self):
        if((self.list[self.x][self.y])=='.'):
            print("No Chess elements available at this position")
        else:
            print(self.list[self.x][self.y])
P=position()
P.get_position()


