import matplotlib.pyplot as plt
import numpy as np

#Bar and Pie plot with Task 1 and Task 2
#Task 1:

vector=np.arange(10,50)
Reverse_vector=vector[::-1]
print("The REVERSE VECTOR IS \n" ,Reverse_vector," +","\n")
#take a height as
#plt.plot(Reverse_vector)
plt.bar(Reverse_vector,10)
plt.pie(Reverse_vector)
plt.show()

#Task2:
# to create random :
A=np.random.random((5,5))
print("the random array:\n")
print(np.array(A))


#Maximum and minimum value in 5X5 matrix
A_max=A.max
A_min=A.min
print("The maximum value in array:\n",A_max)
print("The minimum value in array:\n",A_min)


#The above output gave me address of of both maximum and minimum so
A_max=A.max()
A_min=A.min()
print("maximum and minimum value:\n",A_max,A_min)
#Create bar graph for maximum and minimum value 
plt.bar(A_max,10)
plt.bar(A_min,10)
plt.show()
    
