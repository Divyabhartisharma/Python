#Completed Task 1 to Task 4


#Tasks:

##Create a vector with values ranging from
##10 to 49. Reverse a vector (first element
##becomes last)

import numpy as np


#for i in range(10,49):
    #print(i)
    #vector=np.array(i)
    #print(vector)
#To create a list of elements in python we use arange in numpy module

vector=np.arange(10,50)
print("The vector is\n",vector," +","\n")

#this will remove one last element 
Reverse_vector=vector[:-1]
print("again vector is \n" ,Reverse_vector," +","\n")

Rev_vector=vector[::-1]
print("The REVERSE VECTOR IS \n" ,Rev_vector," +","\n")

#now it is giving the correct output

#Task2:
##Create a 5x5 array with random values.
##and find the minimum and maximum
##values

# to create random :
A=np.random.random((5,5))
print("the random array:\n")
print(np.array(A))
#Maximum and minimum value in 5X5 matrix
A_max=A.max
A_min=A.min
print("The maximum value in array:\n",A_max)
print("The minimum value in array:\n",A_min)

#The above output gave me address of of both maximum and minimum so
A_max=A.max()
A_min=A.min()
print("maximum and minimum value:\n",A_max,A_min)
   
#Task 3:
#Normalize a 5x5 random matrix
#Here i will convert 0.0.. values as 0 and 0.9... something will be as 1 
A=np.random.random((5,5))
print("The rendom matrix is:\n",A," +","\n")
A_max=A.max()
A_min=A.min()
ANormalize=(A-A_min)/(A_max-A_min)
print("the normalize matrix:\n",ANormalize," +","\n")


#Task 4:
#Multiply a 5x3 matrix by a 3x2 matrix (real) matrix product
Five_matrix=np.random.random((5,3))
Three_matrix=np.random.random((3,2))
print("The five matrix:\n",Five_matrix)
print("The Three matrix:\n",Three_matrix)
New_matrix=np.dot(Five_matrix,Three_matrix)
print("Now the new dot matrix is:\n",New_matrix)
