Genarated output of the all the tasks which has been provided in homework 4 using numpy and matplotlib after installing via pip
in python 
once installation is successful the module takes all the numpy related random values ,ceil ,integers
Also generated the Bar and pie graph for task 1 and task 2 as given in the numpy.pdf task file 
Here i have learned the syntax mostly use for vector 2d list ,array concept.
the github link is :
"https://github.com/Divyabhartisharma/Python"

