#TASK 5:
#How to get the dates of yesterday, today and tomorrow?

import numpy as np

#here i can directly use datetime from numpy for present date 
Date_Today=np.datetime64('Today','D')
#Here with present date i need to get previous date for ex: today is 22 then yesterday was 21 so
#i use timedelta with the reference of 1,day which it is giving previous day data

Date_Yesterday=np.datetime64('Today','D')-np.timedelta64(1,'D')
#Here with present date i need to get tommorrow date for ex: today is 22 then Tommorrow will be 23 so
#i use timedelta with the reference of 1,day which it is giving previous day data

Date_Tommorrow=np.datetime64('Today','D')+np.timedelta64(1,'D')
print("Yesterday date was :\n",Date_Yesterday)
print("today date is :\n",Date_Today)
print("Tommorrow date will :\n",Date_Tommorrow)

#Task 6:

#one method is to use random and other to use uniform:
#uniform will create and array of 5 elements in next line i have printed it 
I=np.random.uniform((0,5,5))
print('The unifor array is:\n',I)
print ("Method1:\n",I-I%1)
print ("Method2:\n",np.floor(I))
print ("Method3:\n",np.ceil(I)-1)
#Here below the ascii format in integer for array

print ("Method4:\n",I.astype(int))
print ("Method5:\n",np.trunc(I))

Int_Ran = np.random.random((2,2))
print("The help command:\n ",help(np.random.random))
print('The random array is :\n',Int_Ran)
#From these methods i can directly proint integer value from array

print ("Method1:\n" ,Int_Ran-Int_Ran%1)
print ("Method2:\n", np.floor(Int_Ran))
print ("Method3:\n" ,np.ceil(Int_Ran)-1)
print ("Method4:\n" ,Int_Ran.astype(int))
print ("Method5:\n", np.trunc(Int_Ran))


#Task 7
##position=np.zeros(5,[('x', float, 1),
##         ('y', float, 1)]
##print("the position of x,y:\n",position)
#can take np.ones and np.zeros for 1 and 0 from the numpy 
S = np.ones(5, [ ('position', [ ('x', float, 1),
                             ('y', float, 1)]),
                ('color',[ ('r', float, 1),
                         ('g', float, 1),
                        ('b', float, 1)])])

print("Structured of x,y and r,g,b is:\n",S)
