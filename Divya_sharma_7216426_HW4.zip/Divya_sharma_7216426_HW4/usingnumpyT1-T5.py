import numpy as np
#Task 1
def generate():
    for i in range(10):
#here yield will return to generate object so instead of return i use yield 
        yield i

#the object is iterable so generate function iterating then the data type i use in generate is integer
#also the default value of count is -1 (to read all the data)
numbers=np.fromiter(generate(),dtype=int,count=-1)
print("New_array :")
print(numbers)


#Task 2:
#A random array of 3X3
A1=np.random.random((3,3))
A2=np.random.random((3,3))

Resulted_array=np.equal(A1,A2)
print("Trying to search eequality:\n",Resulted_array)
Equal_array=np.allclose(A1,A2)
print("Test to check if above equal array is correct or not:",Equal_array)
##if(A1==A2):
##    print("Both array are Equal")
##else:

#Task3:
Random_vector=np.random.random((100,2))

print("Show the random vector:\n",Random_vector)
#use point by point distance syntax with numpy
x,y=np.atleast_2d(Random_vector[:,0],Random_vector[:,1])
print("To check the x,y :\n",(x,y))
#use formula sqrt(x^2+y^2)
d = np.sqrt( (x-x.T)**2 + (y-y.T)**2)
print(d)

#Task 4:
A=np.random.random((2,2))
print("First print the random array:",A)
#Formula to calculate the subtract to mean 
B=A-A.mean(axis=1, keepdims=True)
print("Show the subtract the mean of row:",B)

#Task 5:
#Consider a array same as the first question 
##A=[[1,2,3],
##   [4,5,6],
##   [7,8,9]]
##B=np.array(A)
##print("Vector:\n",B)
##C = B[B[:,1].argsort()] 
##print("After sorting the array:\n",C)

#syntax to be used with random also to select random integer i gave 0-100 it can take any value
#in 3X3 matrix
A=np.random.randint(0,100,(3,3))
print("original random array is:",A)
print("the sorted array is with row1 and row2:")
print(A[A[:,1].argsort()])


##Task 6:
##Rank of matrix

A=[[1,2,3],
    [4,5,6],
    [7,8,9]]
B=np.array(A)
#synatx to be used for calculating the rank of matrix
c=np.linalg.matrix_rank(B)
print("Rank of the given matrix is :",c)


#Task 7:
#i will take one integer of matrix so defined "ones"
array = np.ones((16,16))
#Block size is 4X4
BS= 4
print("Original array is:")
print(array)
#syntax to calculate block size and 4 block together and add them 
result = np.add.reduceat(np.add.reduceat(array, np.arange(0, array.shape[0], BS), axis=0),
                        np.arange(0, array.shape[1], BS), axis=1)
print("\nBlock-sum of 4x4 of the array is:")
print(result)









