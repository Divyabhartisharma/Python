Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
====== RESTART: D:\Masters\FH\Semester1\Python\HW5\PandasTask1_task5.py ======
Total sum is:
 370.0
total NaN in one particular column is:
 4
       Name  Values               RGB      HEX
0     White     4.0  rgb(100,100,100)  #FFFFFF
1    Silver     NaN     rgb(75,75,75)  #C0C0C0
2      Gray    13.0     rgb(50,50,50)  #808080
3     Black     NaN        rgb(0,0,0)  #000000
4       Red    11.0               NaN  #FF0000
5    Maroon    90.0       rgb(50,0,0)  #800000
6    Yellow    80.0    rgb(100,100,0)  #FFFF00
7     Olive    70.0      rgb(50,50,0)  #808000
8      Lime     NaN      rgb(0,100,0)  #00FF00
9     Green    50.0       rgb(0,50,0)  #008000
10     Aqua     NaN               NaN  #00FFFF
11     Teal    30.0      rgb(0,50,50)  #008080
12     Blue     NaN      rgb(0,0,100)  #0000FF
13     Navy    10.0               NaN  #000080
14  Fuchsia     NaN    rgb(100,0,100)  #FF00FF
15   Purple    12.0               NaN  #800080
The new dataframe with column aplphabatically arranged:
         HEX     Name               RGB  Values
0   #FFFFFF    White  rgb(100,100,100)     4.0
1   #C0C0C0   Silver     rgb(75,75,75)     NaN
2   #808080     Gray     rgb(50,50,50)    13.0
3   #000000    Black        rgb(0,0,0)     NaN
4   #FF0000      Red               NaN    11.0
5   #800000   Maroon       rgb(50,0,0)    90.0
6   #FFFF00   Yellow    rgb(100,100,0)    80.0
7   #808000    Olive      rgb(50,50,0)    70.0
8   #00FF00     Lime      rgb(0,100,0)     NaN
9   #008000    Green       rgb(0,50,0)    50.0
10  #00FFFF     Aqua               NaN     NaN
11  #008080     Teal      rgb(0,50,50)    30.0
12  #0000FF     Blue      rgb(0,0,100)     NaN
13  #000080     Navy               NaN    10.0
14  #FF00FF  Fuchsia    rgb(100,0,100)     NaN
15  #800080   Purple               NaN    12.0
>>> 
