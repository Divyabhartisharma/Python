Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
======= RESTART: D:\Masters\FH\Semester1\Python\HW5\Pandas_task6-10.py =======
       Name               RGB  Values
0     White  rgb(100,100,100)     4.0
1    Silver     rgb(75,75,75)     NaN
2      Gray     rgb(50,50,50)    13.0
3     Black        rgb(0,0,0)     NaN
4       Red               NaN    11.0
5    Maroon       rgb(50,0,0)    90.0
6    Yellow    rgb(100,100,0)    80.0
7     Olive      rgb(50,50,0)    70.0
8      Lime      rgb(0,100,0)     NaN
9     Green       rgb(0,50,0)    50.0
10     Aqua               NaN     NaN
11     Teal      rgb(0,50,50)    30.0
12     Blue      rgb(0,0,100)     NaN
13     Navy               NaN    10.0
14  Fuchsia    rgb(100,0,100)     NaN
15   Purple               NaN    12.0
the new csv file is:
        Name      HEX             RGB  Values
1    Silver  #C0C0C0   rgb(75,75,75)     NaN
2      Gray  #808080   rgb(50,50,50)    13.0
3     Black  #000000      rgb(0,0,0)     NaN
4       Red  #FF0000             NaN    11.0
5    Maroon  #800000     rgb(50,0,0)    90.0
6    Yellow  #FFFF00  rgb(100,100,0)    80.0
7     Olive  #808000    rgb(50,50,0)    70.0
8      Lime  #00FF00    rgb(0,100,0)     NaN
9     Green  #008000     rgb(0,50,0)    50.0
10     Aqua  #00FFFF             NaN     NaN
11     Teal  #008080    rgb(0,50,50)    30.0
12     Blue  #0000FF    rgb(0,0,100)     NaN
13     Navy  #000080             NaN    10.0
14  Fuchsia  #FF00FF  rgb(100,0,100)     NaN
total NaN is: 10
new Column Values with NaN replaced by average:
 0      4.0
1     37.0
2     13.0
3     37.0
4     11.0
5     90.0
6     80.0
7     70.0
8     37.0
9     50.0
10    37.0
11    30.0
12    37.0
13    10.0
14    37.0
15    12.0
Name: Values, dtype: float64
The output of dataframe with one dictionary:
      Name  age Education
0   Divya   24   Masters
1  bharti   25     Btech
The output of dataframe with one dictionary:
        Name  age Education
0   Claudia   27       PHD
1  jennifer   30   working
Combined dataframe after append is:
        Name  age Education
0     Divya   24   Masters
1    bharti   25     Btech
2   Claudia   27       PHD
3  jennifer   30   working
The dataframe is:
      X    Y     Z
0   10   30    50
1   20   40    60
2   30  100  1000
3   50  200  2000
4  500  300  3000
[[<AxesSubplot:title={'center':'X'}>]]
