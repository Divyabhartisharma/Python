1. Added all the tasks by implementing the concepts of pandas 
2. in task 1 and task 2 have been added the bar graph  and pie chart by using matplotlib
3. Inside this folder there are two subfolders 
	a) Output:where all the output file included and screenshots of output for time saving purpose 
 	b) pythonfile : Created individual files of all tasks till Task 10 and gave name as T1 to T10 
as in previous task i couldnt added separately so i have manipulated this task.
 Inside readme file a CSV file has been taken input to for some of task for calculation purpose.