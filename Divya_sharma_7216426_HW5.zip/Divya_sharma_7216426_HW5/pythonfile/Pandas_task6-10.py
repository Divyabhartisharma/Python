import pandas as pd
import matplotlib.pyplot as plt 



#Task6:
Dataframe=pd.read_csv('color.csv' )
#Delete one column in pandas here 'HEX' i have deleted
Delete=Dataframe.drop('HEX',axis=1)
print(Delete)

#Delete 1st and last row by using drop
df=pd.read_csv('color.csv' )
#d=df.drop('Silver')
#delete first  and last row by using drop
Delete_rows=df.drop([0,15])
print("the new csv file is:\n",Delete_rows)

#Task 7:

#Read the csv 
df=pd.read_csv('color.csv' )
#Count total NaN
Count=df.isnull().sum().sum()

#Using fillna calculate average 
df = df['Values'].fillna(df['Values'].mean())
print("total NaN is:",Count)
#print NaN with average values 
print("new Column Values with NaN replaced by average:\n",df)

#Task8:

#Create two dictionaries:
##dict1={"X":[1,2],"Y":[4,5],"Z":[10,15]}
##dict2={"P":[11,12],"Q":[20,30],"R":[10,30]}
##Dataframe1=pd.DataFrame(dict1)
##Dataframe2=pd.DataFrame(dict2)
##print("The output of dataframe with one dictionary:\n",Dataframe1)
##print("The output of dataframe with one dictionary:\n",Dataframe2)
###Now Append one dataframe1 into dataframe 2
##Dataframe3 = Dataframe1.append(Dataframe2, ignore_index=True)
##print(Dataframe3)
#here output for Df2 after combining with df1 is NaN value because i have taken two different dictionaries i need to take same dictionsary with x y,z 


#D1 and D2 both with X,Y,Z column
#Create two dictionaries:
d1={"Name":['Divya','bharti'],"age":[24,25],"Education":['Masters','Btech']}
d2={"Name":['Claudia','jennifer'],"age":[27,30],"Education":['PHD','working']}
Df1=pd.DataFrame(d1)
Df2=pd.DataFrame(d2)
#Output of two dictionaries 
print("The output of dataframe with one dictionary:\n",Df1)
print("The output of dataframe with one dictionary:\n",Df2)
#Now Append one dataframe1 into dataframe 2
Df3 = Df1.append(Df2, ignore_index=True)
print("Combined dataframe after append is:\n",Df3)

#Task9

#create a new dictionary
d1={"X":[10,20,30,50,500],"Y":[30,40,100,200,300],"Z":[50,60,1000,2000,3000]}
DH=pd.DataFrame(d1)
print("The dataframe is:\n",DH)
#Create histogram for one column X:
Hist_Column=DH.hist('X')
print(Hist_Column)
plt.show()


#Task10:

# Integer and string values can
# never be correlated.
import pandas as pd

data = {'X': [1, 2, 10, 50],
	'Y': [305, 409, 604, 900],
	'Z': [100, 150, 178, 100],
	'A': [188,119, 1000, 560],
	'B': [760, 980, 780, 900]
	}

df = pd.DataFrame(data)
corrM = df.corr()
print("The correlation matrix of output is:\n",corrM)

