
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 

#Task1. Read CSV file and transfer it into DataFrame

#read the csv file as dataframe by following command
dataframe=pd.read_csv('color.csv' )
print("dataframe list from CSV is:\n",dataframe)
#print(dataframe.to_string())
print("Created bargraph from 'RGB' column in csv file:\n")
bargraph = dataframe.plot.bar(x='RGB')
plt.show()
