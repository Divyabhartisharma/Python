import pandas as pd

#Task10:

# Integer and string values can
# never be correlated.
import pandas as pd

data = {'X': [1, 2, 10, 50],
	'Y': [305, 409, 604, 900],
	'Z': [100, 150, 178, 100],
	'A': [188,119, 1000, 560],
	'B': [760, 980, 780, 900]
	}

df = pd.DataFrame(data)
corrM = df.corr()
print("The correlation matrix of output is:\n",corrM)
