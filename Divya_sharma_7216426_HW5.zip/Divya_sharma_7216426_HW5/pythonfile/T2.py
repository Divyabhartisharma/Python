import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#Task2: Transfer object Series into index column of the dataframe
#First read the index columnn
index_column=pd.read_csv('color.csv',index_col='HEX')
# Use 'HEX' column as index column in dataframe
print("the index column is:\n", index_column)
print("The pie chart is for one column Values :\n")
plot = index_column.plot.pie(y='Values', figsize=(5, 5))
plt.show()
