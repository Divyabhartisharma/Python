import pandas as pd
import numpy as np

#Task3:Change the data in the column of DataFrame according to some condition

#to change the data we can use "loc" for replace
#read the CSV file first
DF=pd.read_csv('color.csv' )
#replace first column element 
DF.loc[DF['Name']=='White','Name']='RED'
print("the new dataframe is:\n" ,DF)
#Replace RGB rgb(50,50,50) column to RGB(1000,1000,1000)
DF.loc[DF['RGB']=='rgb(50,50,50)','RGB']='rgb(1000,1000,1000)'
print(DF)

#Replace HEX column FFFFFF to 100111
DF.loc[DF['HEX']=='#FFFFFF','HEX']='#100111'
print(DF)
