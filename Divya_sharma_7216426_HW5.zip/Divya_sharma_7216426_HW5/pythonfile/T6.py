import pandas as pd

#Task6:
Dataframe=pd.read_csv('color.csv' )
#Delete one column in pandas here 'HEX' i have deleted
Delete=Dataframe.drop('HEX',axis=1)
print(Delete)

#Delete 1st and last row by using drop
df=pd.read_csv('color.csv' )
#d=df.drop('Silver')
#delete first  and last row by using drop
Delete_rows=df.drop([0,15])
print("the new csv file is:\n",Delete_rows)
