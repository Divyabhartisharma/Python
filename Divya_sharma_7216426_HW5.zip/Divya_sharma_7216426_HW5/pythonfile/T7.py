import pandas as pd
#Task 7:

#Read the csv 
df=pd.read_csv('color.csv' )
#Count total NaN
Count=df.isnull().sum().sum()

#Using fillna calculate average 
df = df['Values'].fillna(df['Values'].mean())
print("total NaN is:",Count)
#print NaN with average values 
print("new Column Values with NaN replaced by average:\n",df)
