import pandas as pd
#Task8:

#Create two dictionaries:
##dict1={"X":[1,2],"Y":[4,5],"Z":[10,15]}
##dict2={"P":[11,12],"Q":[20,30],"R":[10,30]}
##Dataframe1=pd.DataFrame(dict1)
##Dataframe2=pd.DataFrame(dict2)
##print("The output of dataframe with one dictionary:\n",Dataframe1)
##print("The output of dataframe with one dictionary:\n",Dataframe2)
###Now Append one dataframe1 into dataframe 2
##Dataframe3 = Dataframe1.append(Dataframe2, ignore_index=True)
##print(Dataframe3)
#here output for Df2 after combining with df1 is NaN value because i have taken two different dictionaries i need to take same dictionsary with x y,z 


#D1 and D2 both with X,Y,Z column
#Create two dictionaries:
d1={"Name":['Divya','bharti'],"age":[24,25],"Education":['Masters','Btech']}
d2={"Name":['Claudia','jennifer'],"age":[27,30],"Education":['PHD','working']}
Df1=pd.DataFrame(d1)
Df2=pd.DataFrame(d2)
#Output of two dictionaries 
print("The output of dataframe with one dictionary:\n",Df1)
print("The output of dataframe with one dictionary:\n",Df2)
#Now Append one dataframe1 into dataframe 2
Df3 = Df1.append(Df2, ignore_index=True)
print("Combined dataframe after append is:\n",Df3)
