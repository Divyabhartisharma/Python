import pandas as pd
import matplotlib.pyplot as plt

#Task9

#create a new dictionary
d1={"X":[10,20,30,50,500],"Y":[30,40,100,200,300],"Z":[50,60,1000,2000,3000]}
DH=pd.DataFrame(d1)
print("The dataframe is:\n",DH)
#Create histogram for one column X:
Hist_Column=DH.hist('X')
print(Hist_Column)
plt.show()



