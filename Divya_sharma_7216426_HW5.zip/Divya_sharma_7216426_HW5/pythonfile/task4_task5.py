import pandas as pd
import numpy as np


#Task4:
DF=pd.read_csv('color.csv' )
#total sum of one column 
Total = DF['Values'].sum()
print("Total sum is:\n", Total)
#Total count of NaN in one column 
T_NaN=DF['RGB'].isna().sum()
print("task4 is:\n")
print("total NaN in one particular column is:\n",T_NaN)

#Task5:

#create a new function swap
def Exchange_columns(DF, column1, column2):
    col_list = list(DF.columns)
    x, y = col_list.index(column1), col_list.index(column2)
    col_list[y], col_list[x] = col_list[x], col_list[y]
    df = DF[col_list]
    print(df)
DF=pd.read_csv('color.csv' )
Exchange_columns(DF,'HEX','Values')
#print("The new dataframe after changing columns is:\n",DF)

#Sort columns alphabatically

DF=DF.reindex(sorted(DF.columns), axis=1)
print("task5 is:\n")
print("The new dataframe with column aplphabatically arranged:\n",DF)


