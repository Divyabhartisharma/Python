1. Firstly installed Django and created a new project in pycharm with followed step by step explantion. 
2. Django dafault takes SQlite here to deal with the databases.
3. First I have created polls from the command line (in project folder) and run the server.
4 Created a sample code for hello users it satisfied then proceed with other applications.
5. and run the server as "http://127.0.0.1:8000/polls" it showed the hellow users:

6. Later on i have changed the created different htmls files and models for the application:
there are total 10 questions available inside the poll :"http://127.0.0.1:8000/polls"

7. I can see the application after running the server by using the command python manage.py runserver 
"http://127.0.0.1:8000/admin/"

8.Github link :”https://github.com/Divyabhartisharma/Python”
9.inside the project i have also added the a quick snapshots of how i have added the question in shell also with different input
choices
10 different result snapsshot also being added 

The application created as: Course_feedback
Logo- FH which is being added in mysite>template>static folder
username:divya
Password:Bittz@0320 
you can set your password by running python manage.py shell and update the user name and paaswrd according to ur use 


