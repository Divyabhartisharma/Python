"program which accepts the radius of a circle from the user and compute the area"

"""area=pi*(r**2)
pi=3.14"""

from math import pi

r=float(input("enter radius of circle:"))
area=pi*(r*r)
print("area of circle: " ,area)


"program to print in reverse order"

Firstname =input("Enter first name: ")
Lastname=input("Enter Last name: ")
print("my name is: "+ Lastname + " " + Firstname)
"print(firstname+lastname)"



"Program to count vowels in a string "
Name=input("enter a name :")
i=0
vowel=input("enter vowel string:")
for j in Name:
   if j in vowel:
        i+=1
print("total:",i)


"""Output:
    Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: D:/Masters/FH/Semester1/Python/HW1/hw.py =============
enter radius of circle:2
area of circle:  12.566370614359172
Enter first name: divya
Enter Last name: sharma
my name is: sharma divya
enter a name :divya
enter vowel string:aeiou
total: 2
"""
