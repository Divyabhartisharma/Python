def last_element(t):
    return t[-1]
#take last element of tuple
   
l1=[(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]
#use sorted method
l2=sorted(l1,key=last_element)
#also printed list 1 to reference
print(l1)
print(l2)



 
