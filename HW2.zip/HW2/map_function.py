def string(str):
    convert =map(list,str)
    return list(convert)
l=['divya','bharti','sharma','age']
print(string(l))
