###trial
##l=[{'mobile':'nokia','price':1000},
##   {'mobile':'samsung','price':150000},
##   {'mobile':'iphone','price':50000},
##   {'mobile':'oneplus','price':60000} ]
##nl=sorted(l,key=lambda d:d['price'])
##print(nl)
##for i in nl:
##    print(i.get('mobile'))
    
l=[{'mobile': 'Nokia', 'model': 216, 'color': 'Black'},
   {'mobile': 'Mi Max', 'model': 2, 'color ': 'Gold'},
   {'mobile': 'Samsung', 'model': 7, 'color': 'Blue'}]
newlist=sorted(l,key=lambda d:d['model'],reverse=True)
#nl=sorted(l,key=lambda d:d['color'])

print(newlist)
#print(nl)
          

