def string(Sentence):
    """Here i use split to split the full string with space and then put in an list"""
    Sentence = Sentence.split()        
    str2 = []
    for i in Sentence:
        if i not in str2:
            str2.append(i)
    #Check the duplicate word"""
        
    #insert the word by append 
    #now we have entered all the words of string into list  
    for i in range(0, len(str2)):
         print('Number of', str2[i], '=', Sentence.count(str2[i]))
#count the word into Sentence"""
         
    
def main():
    Sentence ='divya eats food three times in a day divya sleeps three times in a day'
    string(Sentence)                   
 

 
output:
Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
======== RESTART: D:/Masters/FH/Semester1/Python/HW2/string_count.py ========
>>> main()
Number of divya = 2
Number of eats = 1
Number of food = 1
Number of three = 2
Number of times = 2
Number of in = 2
Number of a = 2
Number of day = 2
Number of sleeps = 1
