#the file for inheritance
#all knight ,rook,bishop,queen,king,pawn move and beat possibilities

from ChessFigure import Chessfigure

#The ROOK which we place at corner of chess board so it can either move straight in both row and column
##
class Rook(Chessfigure):
    def Rook_move(self,x,y):
        Rook.chess_position(self)
        Rook_move=[]
        if self.position[x][y] == 'WR':
            u = [(x, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            d = [(x, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            l = [(x-i, y) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            r = [(x+i, y) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            Rook_move = u + d + l + r
            print("possible moves for rook :\n" ,Rook_move,"\n")
        else:
            print("move for rook is not possible at this place\n")
                  
                  
#The beat will be possible if any elements from black side are in front of rook in both row and column side
                  
    def Rook_beat(self,x,y):
        Rook.chess_position(self)
        if self.position[x][y]== 'BR':
            print("beat possible\n")
        else:
            print("saved")


#Knight in chess can take 2:50 steps so the moves of knight can be possible at these many positions i have appended them in a new list
                  
class Knight(Chessfigure):
    def knight_move(self,x,y):
        Knight_moves=[]
        Knight.chess_position(self)
        if self.position[x][y] == 'WK':
            knight_moves = [(x+2, y+1), (x+2, y-1)
                            ,(x+1, y+2), (x+1, y-2)
                           ,(x-2, y-1), (x-2, y+1)
                            ,(x-1, y+2), (x-1, y-2)]
            print("Knight moved at\n:" ,knight_moves,"\n")
        else:
            print("nothing moved\n")
                  
#The beat of knight will be possible if any black elements are after 2.50 steps so white knight can beat black knight
#from cating it can be saved as like this                   
    def Knight_beat(self,x,y):
        Knight.chess_position(self)
        if self.position[x][y]== 'Bp':
            print("beat possible\n")
        else:
            print("Knight saved\n")




#Bishop can take steps diagonal so the elements can be
        
class Bishop(Chessfigure):
    def Bishop_move(self,x,y):
        Bishop_move=[]
        Bishop.chess_position(self)
        if self.position[x][y] == 'WB':
            ur = [(x+i, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            dr = [(x+i, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            ul = [(x-i, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            dl = [(x-i, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
            Bishop_move = ur + dr + ul + dl
            print("The moves of Bishop are:\n",Bishop_move,"\n")
        else:
            print("No movement\n")
#The beat of Bishop will be possible if any black elements will be available diagnolly so white Bishop can beat black chess elements 

    def Bishop_beat(self,x,y):
        Bishop.chess_position(self)
        if self.position[x][y]== 'Bp':
            print("beat possible\n")
        else:
            print("Bishop saved\n")

##Queen elements move staright and diagnol queen can run anywhere in chess board unless no element is in between
                  
class Queen(Chessfigure):
        def Queen_move(self,x,y):
                Queen_move=[]
                Queen.chess_position(self)
                if self.position[x][y] == 'WQ':
                   uq = [(x+i, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   dq = [(x+i, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   ql = [(x-i, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   dl = [(x-i, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   U = [(x, y+i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   D = [(x, y-i) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   L = [(x-i, y) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   R = [(x+i, y) for i in range(1,8) if 0<=x<8 and 0<=y<8]
                   Queen_move=uq+dq+ql+dl+U+D+L+R
                   print("the possible moves of queen:\n",Queen_move,"\n")
                  
                else:
                  print("no move\n")
#The beat of Queen will be possible if any black elements will be available diagnolly and also in rows and columns white Queencan beat black elements                  
        def Queen_beat(self,x,y):
                Queen.chess_position(self)
                if self.position[x][y]== 'Bp':
                    print("beat possible\n")
                else:
                    print("saved\n")

                  
class King(Chessfigure):
    def King_move(self,x,y):
        King_move=[]
        King.chess_position(self)
        if self.position[x][y] == 'WKi':
            King_move.append([[x+1], [y]])
            King_move.append([[x+1], [y+1]])
            King_move.append([[x], [y+1]])
            King_move.append([[x-1], [y+1]])
            King_move.append([[x-1], [y]])
            King_move.append([[x-1], [y-1]])
            King_move.append([[x], [y-1]])
            King_move.append([[x+1], [y-1]])
            
            print("Possible move for King:\n",King_move,"\n")
        else:
             print("no move for king\n")
             print("if King will move at this position it can be beat by black elements\n")
#The beat of King will be possible if any black elements will be available beside white
#king and adjacent diagnol  white King can beat any black chess elements
                  
    def King_beat(self,x,y):
            if self.position[x][y]== 'Bp':
                print("beat possible\n")
            else:
                print("saved\n")
##
        
class Pawn(Chessfigure):
    #def __init__(self):
        
        def move(self,x,y):
         #take an empty list and defined a new parameter for move the pawn in an empty position
            
           pawn_moves = []
           Pawn.chess_position(self)
           #self.position=position
           if self.position[x][y] == 'Wp':
                pawn_moves.append([[x+1], [y]])
                print("possible moves of pawn from the position defined:\n ",pawn_moves,"\n")
                print("pawn moved\n")
           else:
               print("not moved\n")
#The beat of Pawn will be possible if any black elements will be available Diagonal white
# and adjacent diagnol  white pawn can beat any black chess elements
        def pawn_beat(self,x,y):
            Pawn.chess_position(self)
            pawn_beat=[]
            if self.position[x][y]=='BR':
                print("beat possible for pawn \n")
            else:
                
                print("not possible......")
                print("Because the space is empty no white elements are present so it can moved without beating\n")

#Here are the classes output i can take by calling these classes
                
F=Rook("ROOK","White",'WR')
F.Rook_move(0,0)
F.Rook_beat(7,0)
#calling knight class

F=Knight("Knight","White",'WK')
F.knight_move(0,1)
F.Knight_beat(6,1)
#Calling Bishop class

F=Bishop("Bishop","White",'WB')
F.Bishop_move(0,2)
F.Bishop_beat(6,2)
#Calling Queen class

F=Queen("Queen","White",'WQ')
F.Queen_move(0,3)
F.Queen_beat(6,3)
#calling King class

F=King("King","White",'WKi')
F.King_move(0,4)
F.King_beat(7,4)
#calling Pawn class 
F=Pawn("Pawn","White",'Wp')
F.move(1,0)
F.pawn_beat(4,5)


