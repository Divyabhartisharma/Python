Here I have created three files :
1.Chessboard
2.chessfigure
3.All Players(inheritance)
4.Result screenshots from all classes 

1. Chessboard: 
i have created a class to create a chess board by using 2d list(array)
once the board is created i define a new class for position 
so if i will give input as 1,2 so it will show which element is available on that particular position in the chess board 

2. Chessfigure:
Inside this one Chessfigure class has been created into that i used the title and color for the chess also with it i have taken 
one element and defined possibility of move at how many position it can be moved 
 
3.All players:
In this python code i used the concept of inheritance for the before created class inheritance and defined all the elements 
of chess board by move and beat possible for all elements also the casting for king to save

All this concept i used by using object oriented programming such as classes and inheritance in python with defining 
functions and learnt how to pass self by init function 

